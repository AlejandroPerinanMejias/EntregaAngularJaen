export interface lugar {
    id: string,
    nombre: string
}